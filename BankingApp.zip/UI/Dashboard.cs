﻿using BankingApp.Models;
using BankingApp.Models.Enums;
using MaterialSkin.Controls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Collections;
using System.Drawing.Drawing2D;
using BankingApp.Properties;

namespace BankingApp.UI
{
    public partial class Dashboard : MaterialForm
    {
        public Dashboard()
        {

            InitializeComponent();

            //IEnumerator it = TabControl.TabPages.GetEnumerator();
            //while (it.MoveNext())
            //{
            //    TabPage jt = (TabPage)it.Current;
            //    jt.BackColor = AppSkinHelper.materialSkinManager.BackgroundColor;
            //}

            Account acc = new()
            {
                AccountNumber = 1234567812345678,
                AccountType = Accountt.Credit,
                CIdList = [],
                Amount = 0,
                CreationDate = DateTime.Now,
                ExpirationDate = DateTime.Now,
                Currency = Currency.USD,
                Id = 0,
            };

            int cardCount = 8;
            for (int i = 0; i < cardCount; i++)
            {
                tableLayoutPanel1.RowCount += 1;
                tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 200));
                tableLayoutPanel1.Controls.Add(FormHelpers.AddAccount(acc), 0, i);
            }


            locations.ForEach(y =>
            {
                FormHelpers.AddPayment(this, pay, new Point(20, y + payments_label.Height + 40));
            });
        }
    }
}
