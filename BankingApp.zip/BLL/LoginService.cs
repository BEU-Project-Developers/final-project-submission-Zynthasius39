﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingApp.BLL
{
    public static class LoginService
    {
        public static int LoggedIn { get; set; }
    }
}
